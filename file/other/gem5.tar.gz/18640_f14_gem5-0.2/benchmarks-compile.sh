#!/bin/sh
# Extracts MiBench Suite and builds following benchmarks:
#	1. consumer/jpeg #	2. automotive/qsort #	3. network/dijkstra #	4. office/stringsearch  #	5. telecomm/FFT
#
# Author: Naman Jain <namanj@cmu.edu>
#

if [ -d "mibench" ]; then
  echo "error: Mibench Directory exists"
  exit 1
fi

tar -zxvf mibench.tar.gz
make -C mibench/consumer/jpeg/jpeg-6a/
make -C mibench/automotive/qsort/
make -C mibench/network/dijkstra/
make -C mibench/office/stringsearch/
make -C mibench/telecomm/FFT/
