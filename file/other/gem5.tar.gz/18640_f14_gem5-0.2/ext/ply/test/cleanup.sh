#!/bin/sh

rm -f *~ *.pyc *.pyo *.dif *.out 

